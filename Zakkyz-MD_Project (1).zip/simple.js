// simple.js placeholder
