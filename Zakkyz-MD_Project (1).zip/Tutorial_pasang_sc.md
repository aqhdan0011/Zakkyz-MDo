// Tutorial_pasang_sc.md placeholder
