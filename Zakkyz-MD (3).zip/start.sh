#!/bin/bash
echo "Menjalankan Zakkyz-MD..."
npm install
node index.js
