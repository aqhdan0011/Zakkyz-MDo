# Zakkyz-MD WhatsApp Bot

Bot WhatsApp canggih bertema Donghua, mirip Alya Bot, dikembangkan oleh Aqhdan.

## Cara Menjalankan Bot

### Di Termux (Android)
1. Install Termux dari F-Droid.
2. Jalankan perintah berikut:
```bash
pkg update && pkg upgrade
pkg install git nodejs
git clone <link_repo_kamu>
cd Zakkyz-MD
bash start.sh
```

### Di VPS/Linux
```bash
sudo apt update && sudo apt upgrade
sudo apt install git nodejs npm
git clone <link_repo_kamu>
cd Zakkyz-MD
bash start.sh
```

## Catatan
- Simpan session anda di folder `session/`.
- Konfigurasi ada di `config.json` dan `settings.js`.
- Pastikan file penting tidak dihapus agar bot tidak error.

---

Created with love by Abang Gaya & Aqhdan
